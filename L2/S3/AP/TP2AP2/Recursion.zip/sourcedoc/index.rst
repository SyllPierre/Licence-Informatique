==================
 Recursion project
==================


.. toctree::
   :maxdepth: 1

   tracing_recursion
   fibonacci
   fractals



