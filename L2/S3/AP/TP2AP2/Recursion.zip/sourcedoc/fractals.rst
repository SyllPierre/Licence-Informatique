=================
Drawing fractals
=================


Von Koch curve
==============

.. _fig:all_von_koch:
.. figure:: images/all_von_koch.png
   :align: center
   :width: 50%
   :alt: la courbe de Von Koch de l'ordre 0 à l'ordre 5



Cesaro curve
============


Sierpinski triangle
===================
