Pour les fichiers .rst je pense que mon index est correct n�anmoins je ne sais pas si il fallait en cr�er un pour chaque autre parenthese_checker.

Ensuite, mon checker2 marche correctement pour la totalit� des fichiers donc je ne connaissais pas le probl�me qui devait survenir.
J'ai donc essay� de faire un checker3 correct gr�ce aux explications de mes camarades.
