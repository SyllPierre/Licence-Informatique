======================
:mod:`list1` module
======================

.. automodule:: list1
   :members: __doc__

Class :class:`List`
===================

.. autoclass:: list1.List
				  
				    
Selectors
---------

.. automethod:: list1.List.head

.. automethod:: list1.List.tail

Predicates
----------

.. automethod:: list1.List.is_empty

Special method
--------------

.. automethod:: list1.List.__str__

Exception
=========

.. autoexception:: list1.ListError
