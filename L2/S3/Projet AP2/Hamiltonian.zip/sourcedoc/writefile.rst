=========================
:mod:`writefile` module
=========================

Functions who write one file .dot
==================================

.. autofunction:: writefile.title

.. autofunction:: writefile.writeC

.. autofunction:: writefile.writeS

.. autofunction:: writefile.writePath

.. autofunction:: writefile.writeV1

.. autofunction:: writefile.writeFinal




