===============================
:mod:`writehamiltonien` module
===============================

Functions who write all files .dot and create all images of them
================================================================

.. autofunction:: writehamiltonien.createAllFiles

.. autofunction:: writehamiltonien.createAllImageFiles

