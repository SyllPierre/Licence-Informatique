
def new_trie ():
    pass

def add (n,w):
    pass

def contains (n,w):
    pass

def print_trie (n):
    pass
