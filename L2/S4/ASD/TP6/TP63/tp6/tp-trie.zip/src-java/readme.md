# Auteurs

SYLLEBRANQUE Pierre / DESMAREST Mathilde

# Documentation

Pour crée la documentation il faut utiliser la commande :
```
make doc
```

Pour consulter cette documentation, il faut ouvrir le fichier index.html du dossier date de docs dans un navigateur web.

# Compilation 

Pour compiler, on utilise la commande :
```
make all
```

# Exécution

## Première partie
Pour créer le pdf du Trie, on utilise la commande :
```
make figure1
```

## Seconde partie
Pour créer le pdf du CompactTrie, on utilise la commande :
```
make figure2
```


