package trie ;

public class Trie {

   // TODO
   
   public Trie () {
      // TODO
   }

   public void add (String word) {
      // TODO
   }

   public boolean contains (String word) {
      // TODO
   }

   public void print () {
      // TODO
   }
}
