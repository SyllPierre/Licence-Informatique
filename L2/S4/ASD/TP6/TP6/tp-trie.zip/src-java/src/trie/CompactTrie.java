package trie ;

public class CompactTrie {

   // TODO

   public CompactTrie () {
      // TODO
   }

   public void add (String word) {
      // TODO
   }

   public boolean contains (String word) {
      // TODO
   }

   
   public void print () {
      // TODO
   }

}

