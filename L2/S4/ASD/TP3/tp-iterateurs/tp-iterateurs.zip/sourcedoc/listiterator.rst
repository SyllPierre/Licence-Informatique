~~~~~~~~~~~~~~~~~~~~~~~~~~
:mod:`listiterator` module
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. automodule:: listiterator
   :members:
