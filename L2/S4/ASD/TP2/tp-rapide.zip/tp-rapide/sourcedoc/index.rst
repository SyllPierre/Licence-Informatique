---------
Quicksort
---------

.. toctree::
   :maxdepth: 1

   modules.rst

~~~~~~~~~~
Etat du TP
~~~~~~~~~~

Décrivez ici l'état d'avancement du TP.

~~~~~~~~~~~~~~~~~~~~~~
Réponses aux questions
~~~~~~~~~~~~~~~~~~~~~~

Question 2.2.1
--------------
Des tris en place sont des tris qui ne nécessitent pas de recopie de tableau.
Tout comme le tri rapide, le tri fusion est aussi en place, le tri cocktail ou
encore le tri pair-impair.

Question 2.2.2
--------------
On pourrait vérifier si toutes les valeurs des tranchées données sont bien inférieures
ou égales au pivot (et supérieur).
