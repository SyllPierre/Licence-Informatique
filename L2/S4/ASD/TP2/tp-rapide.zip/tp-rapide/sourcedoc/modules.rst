~~~~~~~~~~~~~~~~~~~~~
:mod:`element` module
~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: element.Element
   :special-members: __init__
   :undoc-members:               
   :members:

~~~~~~~~~~~~~~~~~~~~~~
:mod:`generate` module
~~~~~~~~~~~~~~~~~~~~~~

.. automodule:: generate
   :members:

~~~~~~~~~~~~~~~~~~~~~
:mod:`sorting` module
~~~~~~~~~~~~~~~~~~~~~

.. automodule:: sorting
   :members:

~~~~~~~~~~~~~~~~~~
:mod:`test` module
~~~~~~~~~~~~~~~~~~

.. automodule:: test
   :members:
