package condenses_lex;
public interface Yytoken {
    TokenType getType();
}