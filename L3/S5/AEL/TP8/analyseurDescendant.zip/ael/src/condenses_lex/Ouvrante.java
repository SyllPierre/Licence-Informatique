package condenses_lex;

/**
 *  YYtoken implementation for OUVRANTE
 */

public class Ouvrante extends BaseToken{
 
    public Ouvrante(boolean on){
        super(TokenType.OUVRANTE);
    }
    public String toString(){
        return super.toString();
    }
}