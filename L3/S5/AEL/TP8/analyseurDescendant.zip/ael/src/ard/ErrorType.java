package ard;

public enum ErrorType {
	NO_RULE, UNMATCHING_CHAR; 

}
