/**
 * AEL 2018
 * @author : bruno.bogaert (at) univ-lille.fr
 * Exemple du sujet JFLEX, version 0
 */
public class Yytoken {
  private TokenType type;
  
  public Yytoken(TokenType type){
    this.type = type ;
  }

  public TokenType getType() {
    return type;
  }
}
