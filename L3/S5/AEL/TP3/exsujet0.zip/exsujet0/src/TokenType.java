/**
 * AEL 2018
 * @author : bruno.bogaert (at) univ-lille.fr
 * Exemple du sujet JFLEX, version 0
 */
public enum TokenType{
  ENTIER, IDENT, OPERATEUR;
}
