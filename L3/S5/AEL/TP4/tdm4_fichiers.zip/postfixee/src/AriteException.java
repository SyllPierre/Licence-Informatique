public class AriteException extends Exception{
 public AriteException(){
    super();
 }
}