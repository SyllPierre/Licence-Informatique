/**
 * interface de labellisation des classes d'opérandes
 * @author Bruno.Bogaert (at) univ-lille.fr
 */
public interface Operande extends Yytoken {

}
