schema([a,b,c,d,e,f,g,h,i,j]).

fds([ [[a,b],[c]],[[a],[d,e]],[[b],[f]],[[f],[g,h]],,[[d],[i,j]] ]).


